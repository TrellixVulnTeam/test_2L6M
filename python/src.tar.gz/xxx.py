class Xxx:

    def say(self):
        print("hoge!!!")
